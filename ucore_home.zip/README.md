# uCore Home

Página inicial reconstruída a partir da referência visual fornecida.

## Tecnologias

HTML
CSS
TypeScript
Vite

## Executar

Instale Node.js.

Depois, dentro da pasta do projeto:

npm install
npm run dev

Para produção:

npm run build

A imagem usada no hero está em public/images/heroStudents.jpg.
