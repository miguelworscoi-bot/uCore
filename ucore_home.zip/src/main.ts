import "./styles.css";

type StatItem = {
  label: string;
  value: string;
  icon: string;
};

const stats: StatItem[] = [
  { label: "Escolas", value: "+ 31", icon: "⌂" },
  { label: "Professores", value: "+ 459", icon: "◉" },
  { label: "Alunos", value: "+ 5789", icon: "♙" }
];

const features = [
  "Gestão escolar",
  "Professores",
  "Alunos",
  "Turmas",
  "Avaliações"
];

const app = document.querySelector<HTMLDivElement>("#app");

if (!app) {
  throw new Error("Elemento principal não encontrado.");
}

function statCards(): string {
  return stats.map((item) => `
    <article class="statCard">
      <div class="statIcon">${item.icon}</div>
      <h3>${item.label}</h3>
      <strong>${item.value}</strong>
    </article>
  `).join("");
}

function featureCards(): string {
  return features.map((item, index) => `
    <button class="featureCard" dataFeature="${index}" aria-label="${item}">
      <span>${item}</span>
    </button>
  `).join("");
}

app.innerHTML = `
  <header class="siteHeader">
    <div class="headerInner">
      <a class="brand" href="#" aria-label="uCore início">
        <span class="brandMark">◆</span>
        <span class="brandText">uCore</span>
      </a>

      <nav class="mainNav" aria-label="Navegação principal">
        <button class="navButton pagesButton" type="button">
          Páginas
          <span class="navArrow">⌄</span>
        </button>
        <a href="#about">Sobre</a>
        <a href="#profile">Meu perfil</a>
      </nav>

      <div class="headerActions">
        <button class="notificationButton" type="button" aria-label="Notificações">
          <span class="bellIcon">♧</span>
          <span class="notificationDot"></span>
        </button>
        <button class="startButton" type="button" dataStart>Começar</button>
      </div>

      <div class="pagesMenu" hidden>
        <a href="#schools">Escolas</a>
        <a href="#teachers">Professores</a>
        <a href="#students">Alunos</a>
        <a href="#features">Recursos</a>
      </div>
    </div>
  </header>

  <main>
    <section class="hero" id="home">
      <div class="heroInner">
        <div class="heroCopy">
          <p class="eyebrow">CENTRAL DE EDUCAÇÃO</p>
          <h1>Bem vindo à<br>Central uCore</h1>
          <p class="heroText">Priorizamos a melhor organização da Educação</p>
          <button class="heroButton" type="button" dataStart>Começar</button>
        </div>

        <div class="heroVisual">
          <div class="yellowCircle"></div>
          <div class="wave waveOne"></div>
          <div class="wave waveTwo"></div>
          <img src="/images/heroStudents.jpg" alt="Professora e alunos" class="heroStudents">
        </div>
      </div>
    </section>

    <section class="statsSection" aria-label="Estatísticas">
      <div class="statsGrid">
        ${statCards()}
      </div>
    </section>

    <section class="featuresSection" id="features">
      <div class="featureViewport">
        <div class="featureTrack">
          ${featureCards()}
        </div>
      </div>
    </section>

    <section class="spacerSection"></section>

    <footer class="siteFooter" id="about">
      <div class="footerCloud cloudOne"></div>
      <div class="footerCloud cloudTwo"></div>
      <div class="footerCloud cloudThree"></div>

      <div class="footerContent">
        <div class="footerColumn">
          <h2>#ABOUT</h2>
          <a href="#about">Sobre nós</a>
          <a href="#privacy">Termos de política e Privacidade</a>
        </div>

        <div class="footerColumn">
          <h2>#SUPPORT</h2>
          <a href="mailto:contact@ucore.example">Contact</a>
        </div>

        <div class="copyright">
          <span>Copyright #uCore</span>
          <span>© 2026</span>
        </div>
      </div>
    </footer>
  </main>
`;

const pagesButton = document.querySelector<HTMLButtonElement>(".pagesButton");
const pagesMenu = document.querySelector<HTMLDivElement>(".pagesMenu");

pagesButton?.addEventListener("click", () => {
  if (!pagesMenu) return;
  pagesMenu.hidden = !pagesMenu.hidden;
});

document.addEventListener("click", (event) => {
  const target = event.target as Node;
  if (!pagesButton?.contains(target) && !pagesMenu?.contains(target) && pagesMenu) {
    pagesMenu.hidden = true;
  }
});

document.querySelectorAll<HTMLButtonElement>("[dataStart]").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelector("#features")?.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  });
});

const notificationButton = document.querySelector<HTMLButtonElement>(".notificationButton");

notificationButton?.addEventListener("click", () => {
  notificationButton.classList.toggle("active");
  const dot = notificationButton.querySelector<HTMLSpanElement>(".notificationDot");
  if (dot) dot.style.display = "none";
});

const track = document.querySelector<HTMLDivElement>(".featureTrack");

let currentFeature = 0;

function moveFeatureTrack() {
  if (!track) return;

  const cards = track.querySelectorAll<HTMLElement>(".featureCard");
  if (!cards.length) return;

  currentFeature = (currentFeature + 1) % cards.length;
  const card = cards[currentFeature];

  track.scrollTo({
    left: card.offsetLeft,
    behavior: "smooth"
  });
}

window.setInterval(moveFeatureTrack, 3000);
